---
frameworks:
- Pytorch
license: Apache License 2.0
tasks:
- chatbot

language:
- cn 

tags:
- RL-tuned

tools:
- vllm
---
# llama3.1-8b-instruct 中文DPO版
### 模型介绍
Github：[llama3中文仓库](https://github.com/CrazyBoyM/llama3-Chinese-chat)  
像原版instruct一样，喜欢用有趣中文和表情符号回答问题。  


特点：偏好中文和emoji表情，且不损伤原instruct版模型能力。实测中文DPO版问答性能体验超过现在市面上任何llama3.1中文微调版 （微调会大面积破坏llama3.1原版能力，导致遗忘）  
![Alt text](https://modelscope.cn/api/v1/models/baicai003/Llama3-Chinese-instruct-DPO-beta0.5/repo?Revision=master&FilePath=image.png&View=true)

### 训练细节
DPO(beta 0.5) + lora rank128, alpha256 + 打开"lm_head", "input_layernorm", "post_attention_layernorm", "norm"层训练.  

### 模型部署
网页脚本文件：https://github.com/CrazyBoyM/llama3-Chinese-chat/blob/main/deploy/web_streamlit_for_instruct_v2.py  
已经在模型文件夹里内置了一份web.py，可以直接使用。
```
pip install streamlit
pip install transformers==4.40.1
streamlit run web.py ./llama3.1-8b-instruct-dpo-zh
```

### 模型下载
SDK下载
```bash
#安装ModelScope
pip install modelscope
```
```python
#SDK模型下载
from modelscope import snapshot_download
model_dir = snapshot_download('shareAI/llama3.1-8b-instruct-dpo-zh')
```
Git下载
```
#Git模型下载
git clone https://www.modelscope.cn/shareAI/llama3.1-8b-instruct-dpo-zh.git
```
